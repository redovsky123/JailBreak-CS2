using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Cvars;
using CounterStrikeSharp.API.Modules.Entities;
using CounterStrikeSharp.API.Modules.Events;
using CounterStrikeSharp.API.Modules.Memory;
using CounterStrikeSharp.API.Modules.Menu;
using CounterStrikeSharp.API.Modules.Utils;
using CounterStrikeSharp.API.Modules.Entities.Constants;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Core.Translations;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.DependencyInjection;
using System.Globalization;
using CSTimer = CounterStrikeSharp.API.Modules.Timers;
using System.Drawing;
using System.Diagnostics;
using System;
using System.Net.NetworkInformation;
using Microsoft.Extensions.Logging;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Security.Cryptography;
using System.Reflection;
using System.Numerics;
using System.Reflection.Metadata;
using System.Xml.Linq;
using System.Text.Json.Serialization;
using static System.Formats.Asn1.AsnWriter;
using Vector = CounterStrikeSharp.API.Modules.Utils.Vector;

namespace JailBreak;

public class Jail : BasePlugin
{
    public override string ModuleName => "WardenMenu2";
    public override string ModuleAuthor => "Redovsky";
    public override string ModuleVersion => "0.0.3";
    public static CCSPlayerController? warden;
    public CCSPlayerController? LRCOMMANDMENY;
    public CCSPlayerController? lrAWPt;
    public CCSPlayerController? lrAWPct;
    public CCSPlayerController? lrGranedt;
    public CCSPlayerController? lrGranedct;
    public CCSPlayerController? lrruletkat;
    public CCSPlayerController? lrruletkact;
    public CCSPlayerController? lrknifet;
    public CCSPlayerController? Lrknifect;
    public CCSPlayerController? lrbouncerst;
    public CCSPlayerController? lrbouncersct;
    public CCSPlayerController? freedayplayers;
    public CCSPlayerController? muteplayer;
    public CCSPlayerController? allplayers2;
    public CCSPlayerController? fredaysall;
    public CCSPlayerController? lastlr;
    public CCSPlayerController? muteall;
    public bool mute = false;
    public bool op = false;
    public int fredaysn = 0;
    public bool time = false;
    public bool vkltime = false;
    public bool roundend = false;
    public bool allfridays = false;
    int rouns = 1;

    public bool[] _isPaint = new bool[70];

    private void StartLineTime()
    {
        StartLine();
        AddTimer(0.1f, () =>
        {
            StartLineTime();
        });
    }
    
    private void StartLineTime2()
    {
        StartLine2();
        AddTimer(0.1f, () =>
        {
            StartLineTime2();
        });
    }
    
    private void StartLineTime3()
    {
        StartLine3();
        AddTimer(0.1f, () =>
        {
            StartLineTime3();
        });
    }

    private void StartLineTime4()
    {
        StartLine4();
        AddTimer(0.1f, () =>
        {
            StartLineTime4();
        });
    }

    private void StartLineTime5()
    {
        StartLine5();
        AddTimer(0.1f, () =>
        {
            StartLineTime5();
        });
    }

    private void StartLine()
    {
        var start = lrAWPct.Pawn.Value.AbsOrigin;
        var end = lrAWPt.Pawn.Value.AbsOrigin;
        CreateTagsePoints4(start, end);
    }
    
    private void StartLine2()
    {
        var start = lrruletkact.Pawn.Value.AbsOrigin;
        var end = lrruletkat.Pawn.Value.AbsOrigin;
        CreateTagsePoints6(start, end);
    }
    
    private void StartLine3()
    {
        var start = lrbouncerst.Pawn.Value.AbsOrigin;
        var end = lrbouncersct.Pawn.Value.AbsOrigin;
        CreateTagsePoints7(start, end);
    }
    private void StartLine4()
    {
        var start = lrknifet.Pawn.Value.AbsOrigin;
        var end = Lrknifect.Pawn.Value.AbsOrigin;
        CreateTagsePoints8(start, end);
    }
    private void StartLine5()
    {
        var start = lrGranedct.Pawn.Value.AbsOrigin;
        var end = lrGranedt.Pawn.Value.AbsOrigin;
        CreateTagsePoints9(start, end);
    }
    private void CreateTagsePoints4(CounterStrikeSharp.API.Modules.Utils.Vector end, CounterStrikeSharp.API.Modules.Utils.Vector start)
    { 
        CBeam? beam = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam == null)
        {
            return;
        }
        beam.Teleport(start);
        
        beam.Render = Color.White;
        beam.Width = 3f;
        beam.EndWidth = 1f;

        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam.IsValid) beam.AcceptInput("Kill");
        });
    }
    
    private void CreateTagsePoints5(Vector start2, Vector end2)
    {
        CBeam? beam2 = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam2 == null)
        {
            return;
        }
        beam2.Teleport(start2);
        
        beam2.Render = Color.White;
        beam2.Width = 3f;
        beam2.EndWidth = 1f;

        beam2.EndPos.X = end2.X;
        beam2.EndPos.Y = end2.Y;
        beam2.EndPos.Z = end2.Z;
        beam2.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam2.IsValid) beam2.AcceptInput("Kill");
        });
    }
    
    private void CreateTagsePoints6(Vector start2, Vector end2)
    {
        CBeam? beam2 = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam2 == null)
        {
            return;
        }
        beam2.Teleport(start2);
        
        beam2.Render = Color.White;
        beam2.Width = 3f;
        beam2.EndWidth = 1f;

        beam2.EndPos.X = end2.X;
        beam2.EndPos.Y = end2.Y;
        beam2.EndPos.Z = end2.Z;
        beam2.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam2.IsValid) beam2.AcceptInput("Kill");
        });
    }
    
    private void CreateTagsePoints7(Vector start2, Vector end2)
    {
        CBeam? beam2 = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam2 == null)
        {
            return;
        }
        beam2.Teleport(start2);
        
        beam2.Render = Color.White;
        beam2.Width = 3f;
        beam2.EndWidth = 1f;

        beam2.EndPos.X = end2.X;
        beam2.EndPos.Y = end2.Y;
        beam2.EndPos.Z = end2.Z;
        beam2.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam2.IsValid) beam2.AcceptInput("Kill");
        });
    }
    
    private void CreateTagsePoints8(Vector start2, Vector end2)
    {
        CBeam? beam2 = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam2 == null)
        {
            return;
        }
        beam2.Teleport(start2);
        
        beam2.Render = Color.White;
        beam2.Width = 3f;
        beam2.EndWidth = 1f;

        beam2.EndPos.X = end2.X;
        beam2.EndPos.Y = end2.Y;
        beam2.EndPos.Z = end2.Z;
        beam2.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam2.IsValid) beam2.AcceptInput("Kill");
        });
    }
    
    private void CreateTagsePoints9(Vector start2, Vector end2)
    {
        CBeam? beam2 = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam2 == null)
        {
            return;
        }
        beam2.Teleport(start2);
        
        beam2.Render = Color.White;
        beam2.Width = 3f;
        beam2.EndWidth = 1f;

        beam2.EndPos.X = end2.X;
        beam2.EndPos.Y = end2.Y;
        beam2.EndPos.Z = end2.Z;
        beam2.DispatchSpawn();
        AddTimer(0.1f, () =>
        {
            if (beam2.IsValid) beam2.AcceptInput("Kill");
        });
    }
    public override void Load(bool hotReload)
    {
        RegisterListener<Listeners.OnTick>(() =>
        {
            bool useKey = warden != null && (warden.Buttons & PlayerButtons.Use) == PlayerButtons.Use;
            
            if (useKey)
            {
                if (warden != null) tagsCreate(warden);
            }
        });
        RegisterEventHandler<EventRoundStart>((@event, info) =>
        {
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var terror in allPlayers)
            {
                if (!roundend)
                {
                    terror.PrintToCenterAlert("Время взять КМД 15 секунд");
                }
                MenuManager.CloseActiveMenu(terror);
                StopMute();
            }
            _currentBeams.Clear();
            
           warden = null;
            var terrorist = Utilities.GetPlayers()
                .Where(r => r != null && r.IsValid && r.Team == CsTeam.Terrorist)
                .ToList();
            foreach (var terrore2 in terrorist)
            {
                terrore2.GiveNamedItem(CsItem.Knife);
            }

            var counterterrorist = Utilities.GetPlayers()
                .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist)
                .ToList();
            foreach (var counterterrore2 in counterterrorist)
            {
                counterterrore2.GiveNamedItem(CsItem.M4A1);
                counterterrore2.GiveNamedItem(CsItem.Deagle);
                counterterrore2.GiveNamedItem(CsItem.Knife);
            }

            if (terrorist.Count > 0 && terrorist.Count < 2)
            {
                if (_proverka == false)
                {
                    _proverka = true;
                    tfreedays = 0;
                    var players2 = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                    foreach (var terror in players2)
                    {
                        warden = null;
                        roundend = true;
                    }
                }
            }
            
            op = false;
            tfreedays = 180;

            foreach (var beamHandle in _currentBeams)
            {
                if (beamHandle != null && beamHandle.Value.IsValid)
                {
                    beamHandle.Value.AcceptInput("Kill");
                }
            }

            AddTimer(15f, () =>
            {
                if (warden == null && !roundend)
                {
                    RandomWardenNoMute();
                }
            });
            


            bhops2 = "Выкл";
            noblocks2 = "Выкл";
            gravitas2 = "Выкл";
            
            StartLineTime();
            StartLineTime2();
            StartLineTime3();
            StartLineTime4();
            StartLineTime5();
            return HookResult.Continue;
        });
        
        // Сброс всей окраски игроков в конце раунда
        RegisterEventHandler<EventRoundEnd>((@event, info) =>
        {
            var sdgdg214sdf = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var evrevony in sdgdg214sdf)
            {
                evrevony.PrintToChat("Нажмите на клавишу H чтобы скин ножа сменился");
                pred2.Remove(evrevony);
                killsplayer.Remove(evrevony);
                evrevony.PlayerPawn.Value.Render = Color.FromArgb(255, 255, 255, 255);
                Utilities.SetStateChanged(evrevony.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
                pred2.Remove(evrevony);
                MenuManager.CloseActiveMenu(evrevony);
            }
            
            var players2 = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony4 in players2)
            {
                _playerTimes2.Remove(evrevony4);
                evrevony4.RemoveWeapons();
                if (rouns == 1)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/11.vsnd_c");
                    rouns++;
                }
                else if (rouns == 2)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/12.vsnd_c");
                    rouns++;
                }
                else if (rouns == 3)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/13.vsnd_c");
                    rouns++;
                }
                else if (rouns == 4)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/14.vsnd_c");
                    rouns++;
                }
                else if (rouns == 5)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/15.vsnd_c");
                    rouns++;
                }
                else if (rouns == 6)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/16.vsnd_c");
                    rouns++;
                }
                else if (rouns == 7)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/17.vsnd_c");
                    rouns++;
                }
                else if (rouns == 8)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/18.vsnd_c");
                    rouns++;
                }
                else if (rouns == 9)
                {
                    evrevony4.ExecuteClientCommand("play sounds/musikalcss/19.vsnd_c");
                    rouns++;
                    rouns = 1;
                }
            }
            
            var ALLapaw23 = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var evrevony in ALLapaw23)
            {
                evrevony.PrintToChat("Нажмите на клавишу H чтобы скин ножа сменился");
                pred2.Remove(evrevony);
                killsplayer.Remove(evrevony);
                evrevony.PlayerPawn.Value.Render = Color.FromArgb(255, 255, 255, 255);
                Utilities.SetStateChanged(evrevony.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
                pred2.Remove(evrevony);
                MenuManager.CloseActiveMenu(evrevony);
            }
            
            t30 = 0;
            t120 = 0;
            t60 = 0;
            t30 = 30;
            t120 = 120;
            t60 = 60;
            
            bhops2 = "Выкл";
            noblocks2 = "Выкл";
            gravitas2 = "Выкл";
            DisableFriendlyFire();
            StopMute();
            tfreedays = 0;
            AddTimer(1.0f, () => freedays = false);
            freedayplayers = null;
            
            warden = null;
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var terror in allPlayers)
            {
                MenuManager.CloseActiveMenu(terror);
                terror.VoiceFlags &= ~VoiceFlags.Muted;
            }
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                MenuManager.CloseActiveMenu(evrevony);
                evrevony.GiveNamedItem(CsItem.Knife);
                killsplayer.Remove(evrevony);
                evrevony.PlayerPawn.Value!.Render = Color.FromArgb(255, 255, 255);
                Utilities.SetStateChanged(evrevony.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");

                warden.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(warden!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                warden.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(warden!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
            }
            Server.ExecuteCommand("sv_autobunnyhopping 0");
            Server.ExecuteCommand("sv_enablebunnyhopping 0");
            Server.ExecuteCommand("sv_gravity 799");
            Server.ExecuteCommand("mp_solid_teammates 0");
            Server.ExecuteCommand("sv_airaccelerate 20000");
            
            MenuManager.CloseActiveMenu(warden);
            
            lrAWPt = null;
            lrAWPct = null;
            bouncers = false;
            rulet = false;
            graned = false;
            knife = false;
            noscope = false;
            lrruletkat = null;
            lrruletkact = null;
            lrbouncerst = null;
            lrbouncersct = null;
            lrknifet = null;
            Lrknifect = null;
            lrGranedct = null;
            lrGranedt = null;
            
            bouncers = false;
            rulet = false;
            graned = false;
            knife = false;
            noscope = false;
            op = false;
            roundend = false;
            _proverka = false;
            allfridays = false;
            tfreedays = 0;
            freedayplayers = null;
            StopMute();
            DisableFriendlyFire();
            return HookResult.Continue;
        });
    }

    [ConsoleCommand("css_w")]
    public void OpenCmd(CCSPlayerController? p, CommandInfo command)
    {
        if (p == null || p.Team != CsTeam.CounterTerrorist) return;
        if (p.PawnIsAlive)
        {
            if (!allfridays)
            {
                if (!roundend)
                {
                    if (warden == null)
                    {
                        // Установка 135 хп
                        if (p.PlayerPawn.Value != null)
                        {
                            _isPaint[p.Slot] ^= true;
                            p.PlayerPawn.Value.MaxHealth = 135;
                            Utilities.SetStateChanged(p!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                            p.PlayerPawn.Value.Health = 135;
                            Utilities.SetStateChanged(p!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                            // Мут зеков
                            MuteTerrorists();
                            // Установка игрока в p
                            warden = p;
                            if (p?.Pawn == null || p?.Pawn.Value == null) return;
                            Menu(warden);
                        }

                        // Озвучка 
                        warden.ExecuteClientCommand("play sounds/jail/your_new_cmd.vsnd");
                        // Упоминание о том что игрок теперь КМД
                        p.PrintToCenter($"Вы новый командир");
                        // Упоминание кто новый КМД всем                        if (p?.Pawn == null || p?.Pawn.Value == null) return;
                        var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                        foreach (var terror in allPlayers)
                        {
                            if (terror != warden)
                            {
                                terror.ExecuteClientCommand("play sounds/jail/change_cmd.vsnd");
                            }

                            terror.PrintToChat(
                                $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{p.PlayerName} {ChatColors.DarkBlue} новый командир!!! {ChatColors.Orange}★★★");
                            terror.PrintToChat(
                                $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{p.PlayerName} {ChatColors.DarkBlue} новый командир!!! {ChatColors.Orange}★★★");
                            terror.PrintToChat(
                                $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{p.PlayerName} {ChatColors.DarkBlue} новый командир!!! {ChatColors.Orange}★★★");
                        }
                    }
                    else if (warden == p)
                    {
                        var menu = new CenterHtmlMenu("Меню командира:", this);
                        menu.AddMenuOption("Вылечить всех Т", (p, o) => HealT(), false);
                        menu.AddMenuOption("Открыть все двери", (p, o) => Dooropen(p), false);
                        menu.AddMenuOption("Замутить на 40 секунд", (p, o) => MuteProverka(p), false);
                        menu.AddMenuOption("Гравитация/НоБлок/Бхоп", (p, o) => MenuDopolnenie(p), false);
                        menu.AddMenuOption("Ограничить/Снять бунт", (p, o) => PlayerListBunt(p), false);
                        menu.AddMenuOption("Таймер", (p, o) => MenuTime2(p), false);
                        menu.AddMenuOption("КМД игры", (p, o) => MenuGame2(p), false);
                        menu.AddMenuOption("Взять гранату", (p, o) => GranandMe(p), false);
                        menu.AddMenuOption("Выдать Фридей игроку", (p, o) => FreedaysPlayer(p), false);
                        menu.AddMenuOption("Общий Фридей", (p, o) => AllFreedays(p), false);
                        menu.AddMenuOption("Передать КМД", (p, o) => PeredachaKMD(p), false);

                        menu.Open(p);
                    }
                }
                else if (roundend)
                {
                    p.PrintToChat(
                        $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Нельзя взять командира в конце раунда");
                }
            }
            else
            {
                p.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Нельзя взять командира во время общего Фридея");
            }
        }
        else
        {
            p.PrintToChat(
                $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Нельзя взять командира когда вы мертвый");
        }
    }
    
    List<CCSPlayerController> killsplayer = new List<CCSPlayerController>();


    [GameEventHandler]
    public HookResult Pings(EventPlayerPing @event, GameEventInfo info)
    {

        float xPing = @event.X;
        float yPing = @event.Y;
        float zPing = @event.Z;
        
        return HookResult.Continue;
    }
    
    
    [GameEventHandler]
    public HookResult Death(EventPlayerDeath @event, GameEventInfo info)
    {
        if (_playerTimes2.ContainsKey(@event.Userid))
        {
            @event.Attacker.PrintToChat($" {ChatColors.Blue}[Бунт] {ChatColors.DarkBlue} +90 секунд к бунту");
            _playerTimes2[@event.Attacker] =  _playerTimes2[@event.Attacker] + 90;
        }

        _playerTimes.Remove(@event.Userid);
        LastRequest(@event.Userid);
        Reset(@event.Userid);

        if (warden == @event.Userid)
        {
            MenuManager.CloseActiveMenu(warden);
            warden = null;
            StopMute();
            RandomWardenNoMute();
        }

        return HookResult.Continue;
    }

    bool _proverka = false;

    [GameEventHandler]
    public HookResult Disconnect(EventPlayerDisconnect @event, GameEventInfo info)
    {
        killsplayer.Remove(@event.Userid);
        CloseMenu(@event.Userid);
        LastRequest(@event.Userid);
        Reset(@event.Userid);
        if (warden == @event.Userid )
        {
            MenuManager.CloseActiveMenu(warden);
            warden = null;
            StopMute();
            RandomWardenNoMute();
        }
        return HookResult.Continue;   
    }

    [GameEventHandler]
    public HookResult FirePlayer(EventWeaponFire player, GameEventInfo info)
    {
        bool useKey = (warden?.Buttons & PlayerButtons.Use) == PlayerButtons.Use;

        if (useKey && player.Userid == warden)
        {
            TagsCreate2(player.Userid!);
        }

        return HookResult.Continue;
    }

    private void CloseMenu(CCSPlayerController? caller)
    {
        if (caller == warden)
        {
            if (caller != null) MenuManager.CloseActiveMenu(caller);
        }

        if (caller == LRCOMMANDMENY)
        {
            if (caller != null) MenuManager.CloseActiveMenu(caller);
        }
    }
    
    
    private int tfreedays = 180;
    private void LastRequest(CCSPlayerController? caller)
    {
        var terrorist = Utilities.GetPlayers()
            .Where(r => r.Team == CsTeam.Terrorist && r.PlayerPawn.Value?.LifeState == (byte)LifeState_t.LIFE_ALIVE)
            .ToList();
        if (caller == null && caller.Team == CsTeam.Terrorist && _proverka != false && terrorist.Count >= 2 && terrorist.Count != 0)
        {
            switch (terrorist.Count)
            {
                case 0:
                    return;
                case > 0:
                {
                    
                    _proverka = true;
                    tfreedays = 0;
                    AddTimer(1f, () => tfreedays = 180);
                    var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                    foreach (var terror in allPlayers)
                    {
                        if (terrorist.Count == 2)
                        {
                            terror.ExecuteClientCommand("play sounds/jail/last_request.vsnd");
                            terror.PrintToCenter("Последние желаение! Подсказка в чате");
                            terror.PrintToChat($" {ChatColors.Red}Подсказка: ");
                            terror.PrintToChat(
                                $" {ChatColors.Blue}---->{ChatColors.Orange}У вас есть 15 секунд чтобы написать !lr, выбарть игру и активировать ее.");
                        }
                        warden = null;
                        roundend = true;
                        allfridays = false;
                    }
                    break;
                }
            }   
        }
    }

    private void Reset(CCSPlayerController? caller)
    {
        if (caller == lrAWPct)
        {
            noscope = false;
            lrAWPct = null; 
            lrAWPt = null;
            lrAWPt?.PrintToCenter("Вы победили!");
            noscope = false;
        }
        else if (caller == lrAWPt)
        {
            noscope = false;
            lrAWPct = null;
            lrAWPt = null;
            lrAWPct?.PrintToCenter("Вы победили!");
            noscope = false;
        }

        if (caller == lrGranedct)
        {
            graned = false;
            lrGranedct = null;
            lrGranedt = null;
            lrGranedt?.PrintToCenter("Вы победили!");
            noscope = false;
        }
        else if (caller == lrGranedt)
        {
            graned = false;
            lrGranedct = null;
            lrGranedt = null;
            lrGranedct?.PrintToCenter("Вы победили!");
            noscope = false;
        }

        if (caller == lrruletkact)
        {
            knife = false;
            lrruletkact = null;
            lrruletkat = null;
            lrruletkat?.PrintToCenter("Вы победили!");
        }
        else if (caller == lrruletkat)
        {
            knife = false;
            lrruletkact = null;
            lrruletkat = null;
            lrruletkact?.PrintToCenter("Вы победили!");
        }

        if (caller == Lrknifect)
        {
            knife = false;
            Lrknifect = null;
            lrknifet = null;
            lrknifet?.PrintToCenter("Вы победили!");
        }
        else if (caller == lrknifet)
        {
            knife = false;
            Lrknifect = null;
            lrknifet = null;
            Lrknifect?.PrintToCenter("Вы победили!");
        }

        if (caller == lrbouncersct)
        {
            bouncers = false;
            lrbouncersct = null;
            lrbouncerst = null;
            lrbouncerst?.PrintToCenter("Вы победили!");
        }
        else if (caller == lrbouncerst)
        {
            bouncers = false;
            lrbouncersct = null;
            lrbouncerst = null;
            lrbouncersct?.PrintToCenter("Вы победили!");
        }
    }

    List<CCSPlayerController> pred2 = new List<CCSPlayerController>();

    [GameEventHandler]
    public HookResult HurtWarning(EventPlayerHurt @event, GameEventInfo info)
    {
        bool useKey = (warden.Buttons & PlayerButtons.Attack2) == PlayerButtons.Attack2;

        if (useKey && !pred2.Contains(@event.Userid) && @event.Userid.Team == CsTeam.Terrorist)
        {
            StartTimer(@event.Userid);
            @event.Userid.PlayerPawn.Value.Render = Color.FromArgb(220, 20, 60);
            Utilities.SetStateChanged(@event.Userid.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
            pred2.Add(@event.Userid);
        } 
        else if (useKey && pred2.Contains(@event.Userid) && @event.Userid.Team == CsTeam.Terrorist)
        {
            _playerTimes.Remove(@event.Userid); // Удаляем игрока из словаря после окончания таймера
            @event.Userid.PlayerPawn.Value.Render = Color.FromArgb(255, 255, 255, 255);
            Utilities.SetStateChanged(@event.Userid.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
            pred2.Remove(@event.Userid);
        }

        return HookResult.Continue;
    }

    private readonly Dictionary<CCSPlayerController, int> _playerTimes = new();

    private void StartTimer(CCSPlayerController p)
    {
        if (_playerTimes.TryAdd(p, 15))
        {
            Time(p);
        }
    }

    private void Time(CCSPlayerController p)
    {
        if (_playerTimes.TryGetValue(p, out var value))
        {
            AddTimer(1f, () =>
            {
                if (_playerTimes[p] == 0)
                {
                    _playerTimes.Remove(p); // Удаляем игрока из словаря после окончания таймера
                    return;
                }

                if (_playerTimes[p] > 0)
                {
                    p.PrintToCenterAlert($"\u26a0\ufe0f Вы нарушили приказ! \u26a0\ufe0f  \n" +
                                         $"Теперь вас могут убить при малейшем  \n ");
                    _playerTimes[p]--;
                }

                Time(p);
            });
        }
    }


    // LastRequest
    [ConsoleCommand("css_lr")]
    public void LRmenu(CCSPlayerController? caller, CommandInfo command)
    {
        LRCOMMANDMENY = caller;
        var players = Utilities.GetPlayers()
            .Where(r => r != null && r.IsValid && r.Team == CsTeam.Terrorist && r.PawnIsAlive)
            .ToList();
        if (caller.Team == CsTeam.Terrorist)
        {
            if (players.Count <= 2)
            {
                if (caller.PawnIsAlive)
                {
                    if (caller == lrAWPt)
                    {
                        caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Вы уже в LR");
                    }
                    else if (caller == lrGranedt)
                    {
                        caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Вы уже в LR");
                    }
                    else if (caller == lrruletkat)
                    {
                        caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Вы уже в LR");
                    }
                    else if (caller == lrknifet)
                    {
                        caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Вы уже в LR");
                    }
                    else
                    {
                        MenuLR(caller);
                    }
                }
                else
                {
                    caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Вы не живой");
                }
            }
            else
            {
                caller.PrintToChat(
                    $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}LR можно запустить когда останется всего 2 живых зека");
            }
        }
        else if (caller.Team == CsTeam.CounterTerrorist)
        {
            caller.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя использовать LR за кт");
        }
    }

    [GameEventHandler]
    public HookResult ClearItems(EventItemEquip @event, GameEventInfo info)
    {
        if (@event.Userid == freedayplayers)
        {
            @event.Userid.RemoveWeapons();
        }

        return HookResult.Continue;
    }


    [GameEventHandler]
    public HookResult Zoom(EventWeaponZoom @event, GameEventInfo info)
    {
        if (@event.Userid == lrAWPct)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.AWP);
        }

        if (@event.Userid == lrAWPt)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.AWP);
        }

        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult Graned(EventGrenadeBounce @event, GameEventInfo info)
    {
        if (@event.Userid == lrGranedct)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.HEGrenade);
        }
        else if (@event.Userid == lrGranedt)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.HEGrenade);
        }

        // вышибалы
        if (@event.Userid == lrbouncersct)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.DecoyGrenade);
        }
        else if (@event.Userid == lrbouncerst)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.DecoyGrenade);
        }

        return HookResult.Continue;
    }

    bool l1 = false; // стреляет Т
    bool l2 = false; // стреляет КТ

    [GameEventHandler]
    public HookResult GuntRuletka(EventWeaponFire @event, GameEventInfo info)
    {
        if (@event.Userid == lrruletkact && l2)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.Knife);
            lrruletkat.GiveNamedItem(CsItem.Deagle);
            l1 = true;
            l2 = false;
        }

        if (@event.Userid == lrruletkat && l1)
        {
            @event.Userid.RemoveWeapons();
            @event.Userid.GiveNamedItem(CsItem.Knife);
            lrruletkact.GiveNamedItem(CsItem.Deagle);
            l1 = false;
            l2 = true;
        }

        return HookResult.Continue;
    }

    public void MenuLR(CCSPlayerController? caller)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Выберите игру", this);

        menu.AddMenuOption("НоСкоп", (p, o) => NoScope(caller), false);
        menu.AddMenuOption("Гранаты", (p, o) => Graned(caller), false);
        menu.AddMenuOption("Рулетка", (p, o) => Ruletka(caller), false);
        menu.AddMenuOption("Ножи", (p, o) => Knife(caller), false);
        menu.AddMenuOption("Вышибалы", (p, o) => bouncers2(caller), false);
        menu.Open(caller);
    }

    // Вышибалы

    bool bouncers = false;

    public void bouncers2(CCSPlayerController caller)
    {
        if (bouncers == false)
        {
            Viborbouncers(caller);
        }
        else if (bouncers == true)
        {
            caller.PrintToChat(
                $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя выбрыть игру в которую играют уже другие люди");
        }
    }

    public void Viborbouncers(CCSPlayerController? caller)
    {
        var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                bouncers = true;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToChat(
                        $" {ChatColors.Blue}[*SA: LR*] >> {ChatColors.BlueGrey}Игрок {caller.PlayerName} | запустил последние желание c | {controller.PlayerName}");
                }
                MenuManager.CloseActiveMenu(caller);
                MenuManager.CloseActiveMenu(controller);
                caller.RemoveWeapons();
                controller.RemoveWeapons();

                caller.PlayerPawn.Value.Health = 1;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                caller.PlayerPawn.Value.MaxHealth = 1;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                controller.PlayerPawn.Value.Health = 1;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                controller.PlayerPawn.Value.MaxHealth = 1;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                AddTimer(1.0f, () =>
                {
                    controller.PrintToCenter("До LR (3)");
                    caller.PrintToCenter("До LR (3)");
                    caller.RemoveWeapons();
                    controller.RemoveWeapons();
                    AddTimer(1.0f, () =>
                    {
                        controller.PrintToCenter("До LR (2)");
                        caller.PrintToCenter("До LR (2)");
                        caller.RemoveWeapons();
                        controller.RemoveWeapons();
                        AddTimer(1.0f, () =>
                        {
                            controller.PrintToCenter("До LR (1)");
                            caller.PrintToCenter("До LR (1)");
                            caller.RemoveWeapons();
                            controller.RemoveWeapons();
                            AddTimer(1.0f, () =>
                            {
                                controller.PrintToCenter("Начали!");
                                caller.PrintToCenter("Начали!");
                                controller.GiveNamedItem(CsItem.DecoyGrenade);
                                caller.GiveNamedItem(CsItem.DecoyGrenade);
                            });
                        });
                    });
                });
                lrbouncerst = caller;
                lrbouncersct = controller;
                lrbouncerst.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrbouncerst.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");

                lrbouncersct.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrbouncersct.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");
            });
        }

        menu.Open(caller);
    }

    // Ножи

    bool knife = false;

    public void Knife(CCSPlayerController caller)
    {
        if (knife == false)
        {
            ViborKnife(caller);
        }
        else if (knife == true)
        {
            caller.PrintToChat(
                $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя выбрыть игру в которую играют уже другие люди");
        }
    }

    public void ViborKnife(CCSPlayerController? caller)
    {
        var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                knife = true;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToChat(
                        $" {ChatColors.Blue}[*SA: LR*] >> {ChatColors.BlueGrey}Игрок {caller.PlayerName} | запустил последние желание c | {controller.PlayerName}");
                }
                MenuManager.CloseActiveMenu(caller);
                MenuManager.CloseActiveMenu(controller);
                caller.RemoveWeapons();
                controller.RemoveWeapons();

                caller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                caller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                controller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                controller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                AddTimer(1.0f, () =>
                {
                    controller.PrintToCenter("До LR (3)");
                    caller.PrintToCenter("До LR (3)");
                    caller.RemoveWeapons();
                    controller.RemoveWeapons();
                    AddTimer(1.0f, () =>
                    {
                        controller.PrintToCenter("До LR (2)");
                        caller.PrintToCenter("До LR (2)");
                        caller.RemoveWeapons();
                        controller.RemoveWeapons();
                        AddTimer(1.0f, () =>
                        {
                            controller.PrintToCenter("До LR (1)");
                            caller.PrintToCenter("До LR (1)");
                            caller.RemoveWeapons();
                            controller.RemoveWeapons();
                            AddTimer(1.0f, () =>
                            {
                                controller.PrintToCenter("Начали!");
                                caller.PrintToCenter("Начали!");
                                controller.GiveNamedItem(CsItem.Knife);
                                caller.GiveNamedItem(CsItem.Knife);
                            });
                        });
                    });
                });
                lrknifet = caller;
                Lrknifect = controller;
                lrknifet.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrknifet.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");

                Lrknifect.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                Lrknifect.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");
            });
        }

        menu.Open(caller);
    }

    // Рулетка

    bool rulet = false;

    public void Ruletka(CCSPlayerController caller)
    {
        if (rulet == false)
        {
            ViborRuletka(caller);
        }
        else
        {
            caller.PrintToChat(
                $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя выбрыть игру в которую играют уже другие люди");
        }
    }

    public void ViborRuletka(CCSPlayerController? caller)
    {
        var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                rulet = true;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToChat(
                        $" {ChatColors.Blue}[*SA: LR*] >> {ChatColors.BlueGrey}Игрок {caller.PlayerName} | запустил последние желание c | {controller.PlayerName}");
                }                MenuManager.CloseActiveMenu(caller);
                MenuManager.CloseActiveMenu(controller);
                caller.RemoveWeapons();
                controller.RemoveWeapons();

                caller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                caller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                controller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                controller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                AddTimer(1.0f, () =>
                {
                    controller.PrintToCenter("До LR (3)");
                    caller.PrintToCenter("До LR (3)");
                    caller.RemoveWeapons();
                    controller.RemoveWeapons();
                    AddTimer(1.0f, () =>
                    {
                        controller.PrintToCenter("До LR (2)");
                        caller.PrintToCenter("До LR (2)");
                        caller.RemoveWeapons();
                        controller.RemoveWeapons();
                        AddTimer(1.0f, () =>
                        {
                            controller.PrintToCenter("До LR (1)");
                            caller.PrintToCenter("До LR (1)");
                            caller.RemoveWeapons();
                            controller.RemoveWeapons();
                            AddTimer(1.0f, () =>
                            {
                                controller.PrintToCenter("Начали!");
                                caller.PrintToCenter("Начали!");
                                caller.GiveNamedItem(CsItem.Deagle);
                                controller.GiveNamedItem(CsItem.Knife);
                                l1 = true;
                            });
                        });
                    });
                });
                lrruletkat = caller;
                lrruletkact = controller;
                lrruletkat.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrruletkat.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");

                lrruletkact.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrruletkact.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");
            });
        }

        menu.Open(caller);
    }

    // Гранаты

    bool graned = false;

    public void Graned(CCSPlayerController caller)
    {
        if (graned == false)
        {
            VidorGraned(caller);
        }
        else if (graned == true)
        {
            caller.PrintToChat(
                $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя выбрыть игру в которую играют уже другие люди");
        }
    }

    public void VidorGraned(CCSPlayerController? caller)
    {
        var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                graned = true;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToChat(
                        $" {ChatColors.Blue}[*SA: LR*] >> {ChatColors.BlueGrey}Игрок {caller.PlayerName} | запустил последние желание c | {controller.PlayerName}");
                }

                MenuManager.CloseActiveMenu(caller);
                MenuManager.CloseActiveMenu(controller);
                caller.RemoveWeapons();
                controller.RemoveWeapons();

                caller.PlayerPawn.Value.Health = 50;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                caller.PlayerPawn.Value.MaxHealth = 50;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                controller.PlayerPawn.Value.Health = 50;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                controller.PlayerPawn.Value.MaxHealth = 50;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                AddTimer(1.0f, () =>
                {
                    controller.PrintToCenter("До LR (3)");
                    caller.PrintToCenter("До LR (3)");
                    caller.RemoveWeapons();
                    controller.RemoveWeapons();
                    AddTimer(1.0f, () =>
                    {
                        controller.PrintToCenter("До LR (2)");
                        caller.PrintToCenter("До LR (2)");
                        caller.RemoveWeapons();
                        controller.RemoveWeapons();
                        AddTimer(1.0f, () =>
                        {
                            controller.PrintToCenter("До LR (1)");
                            caller.PrintToCenter("До LR (1)");
                            caller.RemoveWeapons();
                            controller.RemoveWeapons();
                            AddTimer(1.0f, () =>
                            {
                                controller.PrintToCenter("Начали!");
                                caller.PrintToCenter("Начали!");
                                caller.PlayerPawn.Value.GravityScale = 0.3f;
                                controller.PlayerPawn.Value.GravityScale = 0.3f;
                                controller.GiveNamedItem(CsItem.HEGrenade);
                                caller.GiveNamedItem(CsItem.HEGrenade);
                                controller.GiveNamedItem(CsItem.Knife);
                                caller.GiveNamedItem(CsItem.Knife);
                            });
                        });
                    });
                });
                lrGranedt = caller;
                lrGranedct = controller;
                lrGranedt.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrGranedt.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");

                lrGranedct.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrGranedct.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");
            });
        }

        menu.Open(caller);
    }

    bool noscope = false;

    public void NoScope(CCSPlayerController caller)
    {
        if (noscope == false)
        {
            ViborNoScope(caller);
        }
        else if (noscope == true)
        {
            caller.PrintToChat(
                $" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Нельзя выбрыть игру в которую играют уже другие люди");
        }
    }

    public void ViborNoScope(CCSPlayerController? caller)
    {
        var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToChat(
                        $" {ChatColors.Blue}[*SA: LR*] >> {ChatColors.BlueGrey}Игрок {caller.PlayerName} | запустил последние желание c | {controller.PlayerName}");
                }
                MenuManager.CloseActiveMenu(caller);
                MenuManager.CloseActiveMenu(controller);
                caller.RemoveWeapons();
                controller.RemoveWeapons();
                noscope = true;

                caller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                caller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(caller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                controller.PlayerPawn.Value.Health = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                controller.PlayerPawn.Value.MaxHealth = 100;
                Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");

                AddTimer(1.0f, () =>
                {
                    controller.PrintToCenter("До LR (3)");
                    caller.PrintToCenter("До LR (3)");
                    caller.RemoveWeapons();
                    controller.RemoveWeapons();
                    AddTimer(1.0f, () =>
                    {
                        controller.PrintToCenter("До LR (2)");
                        caller.PrintToCenter("До LR (2)");
                        caller.RemoveWeapons();
                        controller.RemoveWeapons();
                        AddTimer(1.0f, () =>
                        {
                            controller.PrintToCenter("До LR (1)");
                            caller.PrintToCenter("До LR (1)");
                            caller.RemoveWeapons();
                            controller.RemoveWeapons();
                            AddTimer(1.0f, () =>
                            {
                                controller.PrintToCenter("Начали!");
                                caller.PrintToCenter("Начали!");
                                caller.GiveNamedItem(CsItem.AWP);
                                controller.GiveNamedItem(CsItem.AWP);
                                controller.GiveNamedItem(CsItem.Knife);
                                caller.GiveNamedItem(CsItem.Knife);
                                MenuManager.CloseActiveMenu(caller);
                                MenuManager.CloseActiveMenu(controller);
                            });
                        });
                    });
                });
                lrAWPt = caller;
                lrAWPct = controller;
                lrAWPt.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrAWPt.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");

                lrAWPct.PrintToChat($" {ChatColors.Blue}[SA: LR] >> {ChatColors.Orange}Игра запущена");
                lrAWPct.ExecuteClientCommand("play sounds/ui/logo_startup.vsnd_c");
                
                StartLineTime();
            });
        }

        menu.Open(caller);
    }

    // Луч 
    
private List<CHandle<CBeam>> _currentBeams = new List<CHandle<CBeam>>();

public void TagsCreate2(CCSPlayerController player)
{
    var endPosition = GetEyePosition2(player);
    if (endPosition == null) return;

    CreateBeamCircle(endPosition); // Удалена .Value
    float radius = 150.0f; // Радиус круга
    var playersInCircle = GetPlayersInCircle(endPosition, radius);

    foreach (var p in playersInCircle)
    {
        Console.WriteLine($"Player {p.PlayerName} is in the circle.");
    }
}

private Vector? GetEyePosition2(CCSPlayerController player)
{
    var playerPawn = player.PlayerPawn; // Исправлено
    if (playerPawn == null) return null;

    var pos = playerPawn.Value.AbsOrigin ?? new Vector(0, 0, 0);
    var ang = playerPawn.Value.EyeAngles;

    var result = RayTrace.TraceShape(pos, ang, false, true);
    if (result is null) return null;

    return result;
}

public void CreateBeamCircle(Vector origin)
{
    float radius = 150.0f;
    int pointCount = 100;
    List<Vector> points = new List<Vector>();

    // Удаляем все предыдущие лучи
    foreach (var beamHandle in _currentBeams)
    {
        if (beamHandle != null && beamHandle.IsValid)
        {
            beamHandle.Value.AcceptInput("Kill");
        }
    }
    _currentBeams.Clear();

    for (int i = 0; i < pointCount; i++)
    {
        double angle = i * (2 * Math.PI / pointCount);

        float x = origin.X + (float)(radius * Math.Cos(angle));
        float y = origin.Y + (float)(radius * Math.Sin(angle));
        float z = origin.Z + 5.0f;

        Vector point = new Vector(x, y, z);
        points.Add(point);
    }

    for (int i = 0; i < pointCount; i++)
    {
        Vector start = points[i];
        Vector end = points[(i + 1) % pointCount];
        CreateTagsePoints2(start, end);
    }
}

private void CreateTagsePoints2(Vector start, Vector end)
{
    CBeam? beam = Utilities.CreateEntityByName<CBeam>("beam");

    if (beam == null)
    {
        Console.WriteLine("Ошибка: beam не создан.");
        return;
    }

    // Телепортируем луч к начальной точке
    beam.Teleport(start);

    beam.Render = Color.Cyan;
    beam.Width = 3f;
    beam.EndWidth = 1f;

    beam.EndPos.X = end.X;
    beam.EndPos.Y = end.Y;
    beam.EndPos.Z = end.Z;
    beam.DispatchSpawn();

    // Сохраняем текущий луч в список
    _currentBeams.Add(new CHandle<CBeam>(beam.EntityHandle.Raw));

    // Устанавливаем таймер для удаления луча через 8 секунд
    AddTimer(999.0f, () =>
    {
        foreach (var beamHandle in _currentBeams)
        {
            if (beamHandle != null && beamHandle.IsValid)
            {
                beamHandle.Value.AcceptInput("Kill");
            }
        }

        _currentBeams.Clear();
    });
}

private bool IsPlayerInCircle(Vector playerPosition, Vector circleCenter, float radius)
{
    float distanceSquared = (playerPosition.X - circleCenter.X) * (playerPosition.X - circleCenter.X)
                          + (playerPosition.Y - circleCenter.Y) * (playerPosition.Y - circleCenter.Y);

    return distanceSquared <= radius * radius;
}

private List<CCSPlayerController> GetAllPlayers()
{
    // Этот метод должен вернуть всех игроков на карте.
    // Здесь предположим, что у вас есть способ получить всех игроков
    return new List<CCSPlayerController>(/* список всех игроков */);
}

private List<CCSPlayerController> GetPlayersInCircle(Vector circleCenter, float radius)
{
    List<CCSPlayerController> playersInCircle = new List<CCSPlayerController>();
    var allPlayers = GetAllPlayers();

    foreach (var player in allPlayers)
    {
        var playerPawn = player.PlayerPawn;
        if (playerPawn == null) continue;

        var playerPosition = playerPawn.Value.AbsOrigin ?? new Vector(0, 0, 0);
        if (IsPlayerInCircle(playerPosition, circleCenter, radius))
        {
            playersInCircle.Add(player);
        }
    }

    return playersInCircle;
}

public void tagsCreate(CCSPlayerController player)
    {
        var endPosition = GetEyePosition(player);
        if (endPosition == null) return;

        CreateTagsePoints(endPosition);
    }

    private Vector? GetEyePosition(CCSPlayerController player)
    {
        var playerPawn = player.PlayerPawn.Value;
        if (playerPawn == null) return null;

        var pos = playerPawn.AbsOrigin ?? new Vector(0, 0, 0);
        var ang = playerPawn.EyeAngles;

        var result = RayTrace.TraceShape(pos, ang, false, true);
        if (result is null) return null;

        return result;
    }
    
    private CHandle<CBeam>? _oldBeam;
    
    public void SwitchBeam(CBeam beam)
    {
        if (_oldBeam != null && _oldBeam.Value != null)
            beam.Teleport(_oldBeam.Value.EndPos);

        _oldBeam = new CHandle<CBeam>(beam.EntityHandle.Raw);
    }

    
    int colors = 0; 
    private void CreateTagsePoints(CounterStrikeSharp.API.Modules.Utils.Vector end)
    { 
        CBeam? beam = Utilities.CreateEntityByName<CBeam>("beam");
        
        if (beam == null)
        {
            return;
        }
        beam.Teleport(end);
        SwitchBeam(beam);

        switch (colors)
        {
            case 0:
                beam.Render = Color.Red;
                colors++;
                break;
            case 1:
                beam.Render = Color.Red;
                colors++;
                break;
            case 2:
                beam.Render = Color.Blue;
                colors++;
                break;
            case 3:
                beam.Render = Color.Blue;
                colors++;
                break;
            case 4:
                beam.Render = Color.White;
                colors++;
                break;
            case 5:
                beam.Render = Color.White;
                colors++;
                break;
            case 6:
                beam.Render = Color.Yellow;
                colors++;
                break;
            case 7:
                beam.Render = Color.Yellow;
                colors++;
                break;
            case 8:
                beam.Render = Color.MediumPurple;
                colors++;
                break;
            case 9:
                beam.Render = Color.MediumPurple;
                colors++;
                colors = 0;
                break;
        } 
        beam.Width = 3f;
        beam.EndWidth = 1f;

        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.DispatchSpawn();
        AddTimer(6.0f, () =>
        {
            if (beam.IsValid) beam.AcceptInput("Kill");
        });
    }
    
    // Админ лист 
    [ConsoleCommand("css_help")]
    public void Help(CCSPlayerController? p, CommandInfo command)
    {
        var menu = new CenterHtmlMenu("Выберите пункт:", this);
        menu.AddMenuOption($"Админские команды", (p, o) => admlistcommand(p), false);
        menu.AddMenuOption($"Игровые команды", (p, o) => playsstcommand(p), false);
        menu.Open(p);
    }

    private void admlistcommand(CCSPlayerController? p)
    {
        var menu = new CenterHtmlMenu("Админ команды:", this);
        menu.AddMenuOption($"!admin | Открыть админ меню", (p, o) => Null(), true);
        menu.AddMenuOption($"!ctban | Забанить за КТ", (p, o) => Null(), true);
        menu.AddMenuOption($"!ctunban | Разбанить за КТ", (p, o) => Null(), true);
        menu.AddMenuOption($"!unmute | Размутить игрока", (p, o) => Null(), true);
        menu.AddMenuOption($"!unban | Разбанить игрока", (p, o) => Null(), true);
        menu.Open(p);
    }
    
    private void playsstcommand(CCSPlayerController? p)
    {
        var menu = new CenterHtmlMenu("Игровые команды:", this);
        menu.AddMenuOption($"!w | Взять КМД", (p, o) => Null(), true);
        menu.AddMenuOption($"!ct | Зайти занять очередь за КТ", (p, o) => Null(), true);
        menu.AddMenuOption($"!lr | Последние желание", (p, o) => Null(), true);
        menu.AddMenuOption($"!rtv | Голосовать карту", (p, o) => Null(), true);
        menu.AddMenuOption($"!knife | Выбрать нож", (p, o) => Null(), true);
        menu.AddMenuOption($"!gloves | Сменить перчатки", (p, o) => Null(), true);
        menu.AddMenuOption($"!shop | Магазин за кредиты", (p, o) => Null(), true);
        menu.AddMenuOption($"!admins | Админ лист", (p, o) => Null(), true);
        menu.Open(p);
    }
    
    [ConsoleCommand("css_admins")]
    public void AdminList(CCSPlayerController? p, CommandInfo command)
    {
        var menu = new CenterHtmlMenu("Админ лист:", this);
        menu.AddMenuOption($"_____Главный состав_____", (p, o) => Null(), false);
        menu.AddMenuOption($"Создатель", (p, o) => PlayerInfoOwner(p), false);
        menu.AddMenuOption($"Тех.Админ", (p, o) => PlayerInfoTehAdmin(p), false);
        menu.AddMenuOption($"Гл.Админ", (p, o) => PlayerInfoGlavAdmin(p), false);
            menu.AddMenuOption($"_____Админы в онлайн____", (p, o) => Null(), false);
            var requiredPermissions = new[] { "@css/root", "@css/cvar", "@css/showip", "@css/changemap" };
            
            var adminControllers = Utilities.GetPlayers()
                .Where(controller => 
                    controller != null &&
                    controller.IsValid &&
                    AdminManager.PlayerHasPermissions(controller, "@css/root") || AdminManager.PlayerHasPermissions(controller, "@css/cvar") || AdminManager.PlayerHasPermissions(controller, "@css/showip") || AdminManager.PlayerHasPermissions(controller, "@css/changemap")
                    )
                .ToList();

            foreach (var admin in adminControllers)
            {
                {
                    menu.AddMenuOption(admin.PlayerName, (_, _) =>
                    {
                        PlayerInfoAdmins(admin, p);
                    });
                }
            }

            menu.Open(p);
        }

        private void PlayerInfoTehAdmin(CCSPlayerController p)
        {
            var menu = new CenterHtmlMenu("Информация об Тех.Админе:", this);
            menu.AddMenuOption($"Ник: Редовский", (p, o) => Null(), true);
            menu.AddMenuOption("Ранг: 9", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Тех.Админ", (p, o) => Null(), true);
            menu.Open(p);
        }
        private void PlayerInfoOwner(CCSPlayerController p)
        {
            var menu = new CenterHtmlMenu("Информация об Создателе:", this);
            menu.AddMenuOption($"Ник: Lil Aladin", (p, o) => Null(), true);
            menu.AddMenuOption("Ранг: 10", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Создатель", (p, o) => Null(), true);
            menu.Open(p);
        }
        private void PlayerInfoGlavAdmin(CCSPlayerController p)
        {
            var menu = new CenterHtmlMenu("Информация об Гл.Админе:", this);
            menu.AddMenuOption($"Ник: ӍИ₱₦₳₰", (p, o) => Null(), true);
            menu.AddMenuOption("Ранг: 8", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Гл.Админ", (p, o) => Null(), true);
            menu.Open(p);
        }
        
        private void PlayerInfoAdmins(CCSPlayerController p, CCSPlayerController p2)
        {
            var menu = new CenterHtmlMenu("Информация об админе:", this);
            if (p.SteamID == 76561199703924665)
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 9", (p, o) => Null(), true);
                menu.AddMenuOption("SteamID: 76561199703924665", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Тех.админ", (p, o) => Null(), true);
            }
            else if (p.SteamID == 76561198962397667)
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 8", (p, o) => Null(), true);
            menu.AddMenuOption("SteamID: 76561198962397667", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Гл.админ", (p, o) => Null(), true);
            }
            else if (p.SteamID == 76561199059325837)
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 10", (p, o) => Null(), true);
            menu.AddMenuOption("SteamID: 76561199059325837", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Создатель", (p, o) => Null(), true);
            }
            else if (AdminManager.PlayerHasPermissions(p, "@css/cvar"))
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 1", (p, o) => Null(), true);
            menu.AddMenuOption($"SteamID: {p.SteamID}", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Админ", (p, o) => Null(), true);
            }
            else if (AdminManager.PlayerHasPermissions(p, "@css/changemap"))
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 2", (p, o) => Null(), true);
            menu.AddMenuOption($"SteamID: {p.SteamID}", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Админ", (p, o) => Null(), true);
            }
            else if (AdminManager.PlayerHasPermissions(p, "@css/showip"))
            {
                menu.AddMenuOption($"Ник: {p.PlayerName}", (p, o) => Null(), true);
                menu.AddMenuOption("Ранг: 3", (p, o) => Null(), true);
            menu.AddMenuOption($"SteamID: {p.SteamID}", (p, o) => Null(), true);
            menu.AddMenuOption("Должность: Админ", (p, o) => Null(), true);
            }
            menu.Open(p2);
            
        }

        private void Null()
        {
        }
        

    public void AllFreedays(CCSPlayerController caller)
    {
        t30 = 0;
        t120 = 0;
        t60 = 0;
        
        t30 = 30;
        t120 = 120;
        t60 = 60;
        
        MenuManager.CloseActiveMenu(caller);
        var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
        foreach (var evrevony in players)
        {
            evrevony.PlayerPawn.Value.Render = Color.FromArgb(255, 255, 255);
            Utilities.SetStateChanged(evrevony.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
            fredaysall = evrevony;
        }

        Server.ExecuteCommand("sv_autobunnyhopping 0");
        Server.ExecuteCommand("sv_enablebunnyhopping 0");
        Server.ExecuteCommand("sv_gravity 796");
        freedayplayers = null;
            warden= null;
        allfridays = true;
        fredaysall.PrintToChat(
            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★Запустил общий Фридей ★★★");
        fredaysall.PrintToChat(
            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★ Запустил общий Фридей ★★★");
        fredaysall.PrintToChat(
            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★ Запустил общий Фридей ★★★");
        OpenDoors();
        TimerFreedays();
    }

        
    private  bool stopMute;
    private int muteTimeLeft1 = 40;
    private int muteTimeLeft = 40;
    private bool muteActive;
    
    
    public void GranandMe(CCSPlayerController caller)
    {
        var players = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
        foreach (var evrevony in players)
        {
            evrevony.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}Взял гранату");
        }

        caller.GiveNamedItem(CsItem.HEGrenade);
        caller.ExecuteClientCommand("play sounds/ui/armsrace_level_up_e.vsnd_c");
    }

public void StopMute()
{
    UnMuteAll();
}

public void MuteProverka(CCSPlayerController caller)
{
    if (!mute)
    {
        MuteSound();
    } 
    
    if (mute)
    {
        NotifyCallerMuted(caller);
    }
}

private void NotifyCallerMuted(CCSPlayerController caller)
{
    caller.ExecuteClientCommand("play sounds/training/puck_fail.vsnd");
    caller.PrintToChat($" [SA:Мут] >> {ChatColors.Darkred}Заключенные уже замучены");
}

public void MuteTerrorists()
{
    if (!mutes)
    {
        MuteAllNoSound();
        AddTimer(40.0f, () =>
        {
            if (mutes)
            {
                UnMuteAll();
            }
        });   
    }
}

public void MuteSound()
{
    if (!mutes)
    {
        MuteAll();
        AddTimer(40.0f, () =>
        {
            if (mutes)
            {
                UnMuteAll();
            }
        });   
    }
}

private bool mutes = false;

private void MuteAllNoSound()
{
    if (!mutes)
    {
        var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
        foreach (var player in allPlayers)
        {
            player.PrintToChat($"  {ChatColors.Blue}Командир замутил {ChatColors.Darkred}заключенных {ChatColors.Blue}на {ChatColors.Darkred}40 {ChatColors.Blue}секунд");
            mutes = true;
            if (player.Team == CsTeam.Terrorist)
            {
                player.VoiceFlags |= VoiceFlags.Muted;
            }
        }   
    }
}

private void MuteAll()
{
    if (!mutes)
    {
        var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
        foreach (var player in allPlayers)
        {
            player.ExecuteClientCommand("play sounds/jail/mikrovsem.vsnd");
            player.PrintToChat($"  {ChatColors.Blue}Командир замутил {ChatColors.Darkred}заключенных {ChatColors.Blue}на {ChatColors.Darkred}40 {ChatColors.Blue}секунд");
            mutes = true;
            if (player.Team == CsTeam.Terrorist)
            {
                player.VoiceFlags |= VoiceFlags.Muted;
            }
        }   
    }
}

public void UnMuteAll(bool roundEnd = false)
{
    if (mutes)
    {
        var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
        foreach (var player in allPlayers)
        {
            mutes = false;
            player.VoiceFlags &= ~VoiceFlags.Muted;
            player.PrintToChat($"  [SA: Мут] {ChatColors.Blue}Зеки размучены");
        }
    }
}


    public void Dooropen(CCSPlayerController caller)
    {
        if (op == false)
        {
            op = true;
            var players = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var evrevony in players)
            {
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}Открыл все двери на карте");
                evrevony.ExecuteClientCommand($"play sounds/training/gallery_stop.vsnd");
            }

            OpenDoors();
        }
        else
        {
            caller.ExecuteClientCommand("play sounds/training/puck_fail.vsnd");
            caller.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Клетки джайлов уже открыты!");
        }
    }
    
    public void OpenDoors()
    {
        foreach (KeyValuePair<string, string> door in Doors)
        {
            IEnumerable<CBaseEntity> target = Utilities.FindAllEntitiesByDesignerName<CBaseEntity>(door.Key);

            foreach (CBaseEntity entity in target)
            {
                entity.AcceptInput(door.Value);
            }
        }
    }

    readonly Dictionary<string, string> Doors = new()
    {
        { "func_door", "Open" },
        { "func_breakable", "Break" }
    };
    
        public void HealT()
        {
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var players in allPlayers)
            {
                players.ExecuteClientCommand("play sounds/ui/beep07.vsnd_c");
                players.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}Вылечил всех Т");
                if (players.Team == CsTeam.Terrorist)
                {
                    players.PlayerPawn.Value.Health = 100;
                    Utilities.SetStateChanged(players!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                }
            }
        }

        public void Menu(CCSPlayerController p)
        {
            var menu = new CenterHtmlMenu("Меню командира:", this);
            menu.AddMenuOption("Вылечить всех Т", (p, o) => HealT(), false);
            menu.AddMenuOption("Открыть все двери", (p, o) => Dooropen(p), false);
            menu.AddMenuOption("Замутить на 40 секунд", (p, o) => MuteProverka(p), false);
            menu.AddMenuOption("Гравитация/НоБлок/Бхоп", (p, o) => MenuDopolnenie(p), false);
            menu.AddMenuOption("Ограничить/Снять бунт", (p, o) => PlayerListBunt(p), false);
            menu.AddMenuOption("Таймер", (p, o) => MenuTime2(p), false);
            menu.AddMenuOption("КМД игры", (p, o) => MenuGame2(p), false);
            menu.AddMenuOption("Взять гранату", (p, o) => GranandMe(p), false);
            menu.AddMenuOption("Выдать Фридей игроку", (p, o) => FreedaysPlayer(p), false);
            menu.AddMenuOption("Общий Фридей", (p, o) => AllFreedays(p), false);
            menu.AddMenuOption("Передать КМД", (p, o) => PeredachaKMD(p), false);

            menu.Open(p);
        }

        private void PeredachaKMD(CCSPlayerController p)
        {
                   var menu = new CenterHtmlMenu("С кем вы хотите сыграть", this);
        foreach (var controller in Utilities.GetPlayers()
                     .Where(r => r != null && r.IsValid && r.Team == CsTeam.CounterTerrorist && r.PawnIsAlive)
                     .ToList())
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                if (controller == p)
                {
                    return;
                }
                else
                {
                    warden = controller;
                    MenuManager.CloseActiveMenu(p);
                    var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                    foreach (var terror in allPlayers)
                    {
                        terror.PrintToCenter($"Новый КМД: {warden.PlayerName}");
                        if (terror != warden)
                        {
                            terror.ExecuteClientCommand("play sounds/jail/change_cmd.vsnd");
                        }

                        warden.ExecuteClientCommand("play sounds/jail/your_new_cmd.vsnd");
                        DisableFriendlyFire();
                        terror.PrintToChat(
                            $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{warden.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                        terror.PrintToChat(
                            $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{warden.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                        terror.PrintToChat(
                            $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{warden.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                    }
                }
            });
        }

        menu.Open(p);
        }
        
        public void FreedaysPlayer(CCSPlayerController caller)
        {
            MenuManager.CloseActiveMenu(caller);
            CenterHtmlMenu menu = new CenterHtmlMenu("КМД МЕНЮ", this);
            foreach (var controller in Utilities.GetPlayers()
                         .Where(r => r != null && r.IsValid && r.Team == CsTeam.Terrorist && r.PawnIsAlive)
                         .ToList())
            {
                menu.AddMenuOption(controller.PlayerName, (_, _) =>
                {
                    freedayplayers = controller;
                    var plyaers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                    foreach (var evrevony in plyaers)
                    {
                        evrevony.PrintToChat(
                            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}★★★ Выдал фридей игроку {ChatColors.DarkRed}{controller.PlayerName} ★★★");
                        evrevony.PrintToChat(
                            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}★★★ Выдал фридей игроку {ChatColors.DarkRed}{controller.PlayerName} ★★★");
                        evrevony.PrintToChat(
                            $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Yellow}★★★ Выдал фридей игроку {ChatColors.DarkRed}{controller.PlayerName} ★★★");
                    }

                    freedayplayers.PlayerPawn.Value.Render = Color.FromArgb(154, 205, 50);
                    Utilities.SetStateChanged(freedayplayers.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
                    freedayplayers.PrintToCenter("Вам дали Фридей");
                    controller.PlayerPawn.Value.Health = 99999999;
                    Utilities.SetStateChanged(controller!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
                });
            }

            menu.Open(caller);
        }
        
    public void RandomWardenNoMute()
    {
        if (warden == null)
        {
                 var players = Utilities.GetPlayers().Where(r =>
                r.Team == CsTeam.CounterTerrorist && r?.PlayerPawn.Value?.LifeState == (byte)LifeState_t.LIFE_ALIVE)
            .ToList();

        if (players.Any())
        {
            Random rand = new Random();
            CCSPlayerController wardens = players[rand.Next(players.Count)];
            warden = wardens;
            MuteTerrorists();
            _isPaint[wardens.Slot] ^= true;
            
            wardens.PlayerPawn.Value.MaxHealth = 135;
            Utilities.SetStateChanged(wardens!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
            wardens.PlayerPawn.Value.Health = 135;
            Utilities.SetStateChanged(wardens!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
            Menu(wardens);
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var terror in allPlayers)
            {
                terror.PrintToCenter($"Новый КМД: {warden.PlayerName}");
                if (terror != warden)
                {
                    terror.ExecuteClientCommand("play sounds/jail/change_cmd.vsnd");
                }

                warden.ExecuteClientCommand("play sounds/jail/your_new_cmd.vsnd");
                DisableFriendlyFire();
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                warden.ExecuteClientCommand("bind e tag");
            }

            warden.PrintToCenter($"Вы новый КМД!");
            warden.PlayerPawn.Value.Render = Color.FromArgb(0, 0, 205);
            Utilities.SetStateChanged(warden.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
        }   
        }
    }
        
    public void RandomWarden(CCSPlayerController? caller)
    {
        if (caller != warden) return;
        if (caller != null) MenuManager.CloseActiveMenu(caller);
        warden = null;
        var players = Utilities.GetPlayers().Where(r =>
                r.Team == CsTeam.CounterTerrorist && r?.PlayerPawn.Value?.LifeState == (byte)LifeState_t.LIFE_ALIVE)
            .ToList();

        if (players.Any())
        {
            Random rand = new Random();
            CCSPlayerController wardens = players[rand.Next(players.Count)];
            warden = wardens;
            MuteTerrorists();
            _isPaint[wardens.Slot] ^= true;
            
            wardens.PlayerPawn.Value.MaxHealth = 135;
            Utilities.SetStateChanged(wardens!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
            wardens.PlayerPawn.Value.Health = 135;
            Utilities.SetStateChanged(wardens!.PlayerPawn.Value!, "CBaseEntity", "m_iHealth");
            Menu(wardens);

            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var terror in allPlayers)
            {
                terror.PrintToCenter($"Новый КМД: {warden.PlayerName}");
                if (terror != warden)
                {
                    terror.ExecuteClientCommand("play sounds/jail/change_cmd.vsnd");
                }

                warden.ExecuteClientCommand("play sounds/jail/your_new_cmd.vsnd");
                DisableFriendlyFire();
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                terror.PrintToChat(
                    $" {ChatColors.Orange}★★★{ChatColors.DarkBlue}Игрок {ChatColors.Darkred}{wardens.PlayerName} {ChatColors.DarkBlue}новый командир!!! {ChatColors.Orange}★★★");
                warden.ExecuteClientCommand("bind e tag");
            }

            warden.PrintToCenter($"Вы новый КМД!");
            warden.PlayerPawn.Value.Render = Color.FromArgb(0, 0, 205);
            Utilities.SetStateChanged(warden.PlayerPawn.Value, "CBaseModelEntity", "m_clrRender");
        }
    }
    
    
    
    
    
    
    
    
    
    
    // Доп меню 
    bool bhop2 = false;
    string bhops2 = "Выкл";


    bool noblock2 = false;
    string noblocks2 = "Выкл";

    bool gravit2 = false;
    string gravitas2 = "Выкл";

    public void MenuDopolnenie(CCSPlayerController caller)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);

        menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
        menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
        menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
        menu.Open(caller);
    }

    public void GravitationStart(CCSPlayerController caller)
    {
        if (gravit2 == false)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                gravit2 = true;
                gravitas2 = "Вкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Включил {ChatColors.BlueGrey}Гравитацию ☁☁☁");
                Server.ExecuteCommand("sv_gravity 360");
            }
        }
        else if (gravit2 == true)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                gravitas2 = "Выкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                gravit2 = false;
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Выключил {ChatColors.BlueGrey}Гравитацию ☁☁☁");
                Server.ExecuteCommand("sv_gravity 796");
                float? obj;
                obj = evrevony.AbsOrigin.X;
                
                
            }
        }
    }

    public void BhopStart(CCSPlayerController caller)
    {
        if (bhop2 == false)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                bhop2 = true;
                bhops2 = "Вкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Включил {ChatColors.BlueGrey}Бхоп ☂☂☂");
                Server.ExecuteCommand("sv_airaccelerate 100");
                Server.ExecuteCommand("sv_autobunnyhopping 1");
                Server.ExecuteCommand("sv_enablebunnyhopping 1");
            }
        }
        else if (bhop2 == true)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                bhops2 = "Выкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                bhop2 = false;
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Выключил {ChatColors.BlueGrey}Бхоп ☂☂☂");
                Server.ExecuteCommand("sv_autobunnyhopping 0");
                Server.ExecuteCommand("sv_enablebunnyhopping 0");
            }
        }
    }

    public void NoBlockStart(CCSPlayerController caller)
    {
        if (noblock2 == false)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                noblock2 = true;
                noblocks2 = "Вкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Включил {ChatColors.BlueGrey}НоБлок ♥♥♥");
                Server.ExecuteCommand("mp_solid_teammates 1");
            }
        }
        else if (noblock2 == true)
        {
            var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
            foreach (var evrevony in players)
            {
                noblocks2 = "Выкл";
                MenuManager.CloseActiveMenu(caller);
                CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
                menu.AddMenuOption($"Бхоп [{bhops2}]", (p, o) => BhopStart(caller), false);
                menu.AddMenuOption($"НоБлок [{noblocks2}]", (p, o) => NoBlockStart(caller), false);
                menu.AddMenuOption($"Гравитация [{gravitas2}]", (p, o) => GravitationStart(caller), false);
                menu.Open(caller);
                noblock2 = false;
                evrevony.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Выключил {ChatColors.BlueGrey}НоБлок ♥♥♥");
                Server.ExecuteCommand("mp_solid_teammates 0");
            }
        }
    }
    
    // Пас. Бунт
    
    private void PlayerListBunt(CCSPlayerController player)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Снять или Выдать?", this);
        menu.AddMenuOption("Снять время на бунт", (p, o) => TakeBunt(p), false);
        menu.AddMenuOption("Выдать время на бунт", (p, o) => GiveBunt(p), false);
        menu.Open(player);
    }

    private void TakeBunt(CCSPlayerController player)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Кому снять таймер на бунт?", this);
        foreach (var controller in _playerBunt)
    menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var alls in allPlayers)
                {
                    alls.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Lime}Снял время на {ChatColors.Darkred}бунт {ChatColors.Lime}игроку {ChatColors.BlueGrey}{controller.PlayerName} | \u26a0\ufe0f");
                }

                controller.PrintToCenterAlert($"\u26a0\ufe0f | Вам сняли время на бунт | \u26a0\ufe0f");
                _playerBunt.Remove(controller);
                _playerTimes2.Remove(controller); // Удаляем игрока из словаря после окончания таймера
            });
        menu.Open(player);
    }

    private readonly Dictionary<CCSPlayerController, int> _playerTimes2 = new();
    private readonly HashSet<CCSPlayerController> _playerBunt = new();

    // Метод для выдачи бунта через меню
    private void GiveBunt(CCSPlayerController player)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Кому выдать таймер на бунт?", this);

        // Получаем список игроков из команды контр-террористов, которые живы и валидны
        var players = Utilities.GetPlayers()
            .Where(r => r != null && r.IsValid && r.Team == CsTeam.Terrorist && r.PawnIsAlive)
            .ToList();

        // Добавляем каждого игрока в меню
        foreach (var controller in players)
        {
            menu.AddMenuOption(controller.PlayerName, (_, _) =>
            {
                // Запускаем таймер для выбранного игрока
                StartTimer2(controller);
                _playerBunt.Add(controller);
                // Отправляем сообщение всем игрокам о том, что выдан бунт
                foreach (var allPlayer in Utilities.GetPlayers().Where(x => x.IsValid && x != null))
                {
                    allPlayer.PrintToChat($"{ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Lime}Выдал время на {ChatColors.Darkred}бунт {ChatColors.Lime}игроку {ChatColors.BlueGrey}{controller.PlayerName} | \u26a0\ufe0f");
                }
            });
        }

        // Открываем меню для игрока
        menu.Open(player);
    }

    // Метод для запуска таймера
    private void StartTimer2(CCSPlayerController player)
    {
        // Если игрока нет в словаре, добавляем его с начальным значением таймера
        if (_playerTimes2.TryAdd(player, 90))
        {
            // Запускаем асинхронный метод отсчета времени
            Time2(player);
        }
    }

    // Метод для отсчета времени
    private void Time2(CCSPlayerController player)
    {
        AddTimer(1.0f, () =>
        {
            // Проверяем, есть ли игрок в словаре и получаем оставшееся время
            if (_playerTimes2.TryGetValue(player, out int timeLeft))
            {
                if (timeLeft > 0)
                {
                    // Отправляем уведомление игроку с оставшимся временем
                    player.PrintToCenterAlert($"\u26a0\ufe0f | Время на бунт {timeLeft} | \u26a0\ufe0f");

                    // Уменьшаем время на 1 секунду
                    _playerTimes2[player] = timeLeft - 1;

                    // Рекурсивно вызываем этот метод для следующей секунды
                    Time2(player);
                }
                else
                {
                    // Время истекло, отправляем уведомление и убиваем игрока
                    player.PrintToCenterAlert($"\u26a0\ufe0f | Время вышло | \u26a0\ufe0f");
                    player.CommitSuicide(false, false);

                    // Удаляем игрока из словаря
                    _playerTimes2.Remove(player);
                }
            }
        });
    }
    
    // Таймер 
    
    private void MenuTime2(CCSPlayerController caller)
    {
        CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);

        menu.AddMenuOption($"0:30", (p, o) => StartTime30(caller), false);
        menu.AddMenuOption($"1:00", (p, o) => StartTime60(caller), false);
        menu.AddMenuOption($"2:00", (p, o) => StartTime120(caller), false);
        menu.AddMenuOption($"Остановить таймер", (p, o) => StopTimer(caller), false);
        menu.Open(caller);
    }

    public void StartTime30(CCSPlayerController caller)
    {
        if (vkltime == false)
        {
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            AllSound("play sounds/training/bell_normal.vsnd");
            vkltime = true;
            Timer30();
        }
        else if (vkltime == true)
        {
            caller.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}У вас уже включен таймер");
        }
    }

    public void StartTime60(CCSPlayerController caller)
    {
        if (vkltime == false)
        {
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            AllSound("play sounds/training/bell_normal.vsnd");
            vkltime = true;
            Timer60();
        }
        else if (vkltime == true)
        {
            caller.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}У вас уже включен таймер");
        }
    }

    public void StartTime120(CCSPlayerController caller)
    {
        if (vkltime == false)
        {
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            AllSound("play sounds/training/bell_normal.vsnd");
            vkltime = true;
            Timer120();
        }
        else if (vkltime == true)
        {
            caller.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}У вас уже включен таймер");
        }
    }

    public int t30 = 30;

    public void Timer30()
    {
        AddTimer(1f, () =>
        {
            if (time == true)
            {
                return;
            }
            else if (t30 == 0)
            {
                vkltime = false;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenterAlert($" Время вышло ");
                    terror.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Время вышло!");
                    t30 = 30;
                    // звук
                    AllSound("play sounds/training/puck_fail.vsnd");
                }
            }
            else if (t30 > 0)
            {
                t30--;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenter($" До конца игры {t30}");
                }

                Timer30();
            }

            if (t30 == 29)
            {
                vkltime = true;
            }
        });
    }

    public int t60 = 60;

    public void Timer60()
    {
        AddTimer(1.0f, () =>
        {
            if (time == true)
            {
                return;
            }
            else if (t60 == 0)
            {
                vkltime = false;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenter($" Время вышло ");
                    terror.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Время вышло!");
                    AllSound("play sounds/training/puck_fail.vsnd");
                    t60 = 60;
                    // звук
                }
            }
            else if (t60 > 0)
            {
                t60--;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenter($" До конца игры {t60}");
                }

                Timer60();
            }

            if (t60 == 59)
            {
                vkltime = true;
            }
        });
    }

    public  int t120 = 120;

    public void Timer120()
    {
        AddTimer(1.0f, () =>
        {
            if (time == true)
            {
                return;
            }
            else if (t120 == 0)
            {
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    vkltime = false;
                    terror.PrintToCenterAlert($" Время вышло ");
                    terror.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Время вышло!");
                    t120 = 120;
                    // звук
                    AllSound("play sounds/training/puck_fail.vsnd");
                }
            }
            else if (t120 > 0)
            {
                vkltime = true;
                t120--;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenter($" До конца игры {t120}");
                }

                Timer120();
            }

            if (t120 > 119)
            {
                vkltime = true;
            }
        });
    }

    private void StopTimer(CCSPlayerController caller)
    {
        if (vkltime == true)
        {
            var plyaers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var evrevony in plyaers)
            {
                evrevony.PrintToCenter(" Время вышло ");
                evrevony.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Остановил таймер!");
                AllSound("play sounds/training/puck_fail.vsnd");
            }

            time = true;
            t30 = 30;
            t60 = 60;
            t120 = 120;
            AddTimer(1.0f, () => time = false);
            AddTimer(1.0f, () => vkltime = false);
        }
        else if (vkltime == false)
        {
            caller.PrintToChat($" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.Darkred}Прежде включите таймер");
        }
    }
    
        // КМД игры
    bool BoxEnable = false;
    string BoxEnbales = "Выкл";

    public void MenuGame2(CCSPlayerController caller)
    {
        MenuManager.CloseActiveMenu(caller);
        CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
        menu.AddMenuOption($"Бокс [{BoxEnbales}]", (p, o) => BoxStart(caller), false);
        menu.Open(caller);
    }

    public void BoxStart(CCSPlayerController caller)
    {
        if (BoxEnable == false)
        {
            MenuManager.CloseActiveMenu(caller);
            CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
            BoxEnbales = "Вкл";
            menu.AddMenuOption($"Бокс [{BoxEnbales}]", (p, o) => BoxStart(caller), false);
            menu.Open(caller);
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            BoxEnable = true;
            foreach (var terror in allPlayers)
            {
                AllSound("play sounds/training/bell_normal.vsnd");
                EnableFriendlyFire();
                terror.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Запустил {ChatColors.BlueGrey}бокс (ง'̀-'́)ง");
            }
        }
        else if (BoxEnable == true)
        {
            MenuManager.CloseActiveMenu(caller);
            CenterHtmlMenu menu = new CenterHtmlMenu("Меню командира:", this);
            BoxEnbales = "Выкл";
            menu.AddMenuOption($"Бокс [{BoxEnbales}]", (p, o) => BoxStart(caller), false);
            menu.Open(caller);
            var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
            foreach (var terror in allPlayers)
            {
                terror.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}Остановил {ChatColors.BlueGrey}бокс (ง'̀-'́)ง");
                DisableFriendlyFire();
                AllSound("play sounds/training/puck_fail.vsnd");
            }

            BoxEnable = false;
        }
    }

    public void EnableFriendlyFire()
    {
        if (ff != null)
        {
            ff.SetValue(true);
        }
    }

    public void DisableFriendlyFire()
    {
        if (ff != null)
        {
            ff.SetValue(false);
        }
    }

    ConVar? ff = ConVar.Find("mp_teammates_are_enemies");
    
    
    // Общий ФД
    
    bool freedays = false;

    public void TimerFreedays()
    {
        AddTimer(1.0f, () =>
        {
            if (freedays == true)
            {
                return;
            }
            else if (tfreedays == 0)
            {
                fredaysall.PrintToCenter("Общий Фридей окончен!");
                fredaysall.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★ Общий Фридей окончен! ★★★");
                fredaysall.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★ Общий Фридей окончен! ★★★");
                fredaysall.PrintToChat(
                    $" {ChatColors.Blue}[*SA:Командир*] >> {ChatColors.BlueGrey}★★★ Общий Фридей окончен! ★★★");

                AddTimer(5.0f, () =>
                {
                    allfridays = false;
                    var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
                    foreach (var evrevony in players)
                    {
                        evrevony.CommitSuicide(false, true);
                    }

                    return;
                });
            }
            else if (tfreedays > 0)
            {
                Server.ExecuteCommand("sv_autobunnyhopping 0");
                Server.ExecuteCommand("sv_enablebunnyhopping 0");
                Server.ExecuteCommand("sv_gravity 796");
                tfreedays--;
                var allPlayers = Utilities.GetPlayers().Where(x => x.IsValid && x != null);
                foreach (var terror in allPlayers)
                {
                    terror.PrintToCenter($" До конца общего фридея {tfreedays}");
                }

                TimerFreedays();
            }

            if (tfreedays == 179)
            {
                AllSound("play sounds/training/bell_normal.vsnd");
                RulesFreDay();
            }
            else if (tfreedays == 140)
            {
                RulesFreDay();
            }
            else if (tfreedays == 110)
            {
                RulesFreDay();
            }
            else if (tfreedays == 70)
            {
                RulesFreDay();
            }
            else if (tfreedays == 20)
            {
                RulesFreDay();
            }
        });
    }

    public void RulesFreDay()
    {
        fredaysall.PrintToChat($" {ChatColors.Orange}--------Правила общего Фридея--------");
        fredaysall.PrintToChat(
            $" {ChatColors.Yellow}1 Т могут свободно передвигаться, кроме нычек и зон КТ. Т не могут приближаться к КТ на расстояние удара ножа.");
        fredaysall.PrintToChat($" {ChatColors.Orange}★★★★★★★★★★★★★★★★★★★★★★★★★★★");
        fredaysall.PrintToChat(
            $" {ChatColors.Orange}2 Т также не имеют права носить оружие в руках или за спиной во время передвижения.");
        fredaysall.PrintToChat($" {ChatColors.Orange}★★★★★★★★★★★★★★★★★★★★★★★★★★★");
        fredaysall.PrintToChat(
            $" {ChatColors.Yellow}3 С другой стороны, КТ не допускается находиться в зонах, куда физически не могут проникнуть Т.");
    }

    private void AllSound(string sound)
    {
        var players = Utilities.GetPlayers().Where(r => r != null && r.IsValid);
        foreach (var evrevony in players)
        {
            evrevony.ExecuteClientCommand($"{sound}");
        }
    }
}