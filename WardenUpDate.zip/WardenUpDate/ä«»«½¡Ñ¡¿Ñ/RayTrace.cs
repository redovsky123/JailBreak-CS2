using System.Drawing;
using System.Numerics;
using System.Runtime.InteropServices;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Memory;
using CounterStrikeSharp.API.Modules.Utils;
using Vector = CounterStrikeSharp.API.Modules.Utils.Vector;

public class RayTrace
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private unsafe delegate bool TraceShapeDelegate(
        nint GameTraceManager,
        nint vecStart,
        nint vecEnd,
        nint skip,
        ulong mask,
        byte a6,
        GameTrace* pGameTrace
    );

    private static TraceShapeDelegate _traceShape;

    private static nint TraceFunc = NativeAPI.FindSignature(Addresses.ServerPath, "48 B8 ? ? ? ? ? ? ? ? 55 48 89 E5 41 57 41 56 49 89 D6 41 55");

    private static nint GameTraceManager =
        NativeAPI.FindSignature(Addresses.ServerPath, "48 8D 05 ? ? ? ? F3 0F 58 8D ? ? ? ? 31 FF");

    public static void DrawBeam(Vector startPos, Vector endPos, Color color)
    {
        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null)
        {
            Console.WriteLine("Failed to create beam entity.");
            return;
        }

        beam.Render = color;
        beam.Width = 1.5f;
        beam.Teleport(startPos, new QAngle(), new Vector());
        beam.EndPos.Add(endPos);
        beam.DispatchSpawn();
        Console.WriteLine($"Beam drawn from {startPos} to {endPos} with color {color.Name}.");
    }

    public static unsafe Vector? TraceShape(Vector? origin2, QAngle viewangles, bool drawResult = false, bool fromPlayer = false)
    {
        var gameTraceManagerAddress = Address.GetAbsoluteAddress(GameTraceManager, 3, 7);

        _traceShape = Marshal.GetDelegateForFunctionPointer<TraceShapeDelegate>(TraceFunc);

        var origin = new Vector(origin2.X, origin2.Y, origin2.Z);
        var forward = new Vector();

        NativeAPI.AngleVectors(viewangles.Handle, forward.Handle, 0, 0);
        var endOrigin = new Vector(origin.X + forward.X * 8192,
            origin.Y + forward.Y * 8192, origin.Z + forward.Z * 8192);

        var d = 50;

        if (fromPlayer)
        {
            origin.X += forward.X * d;
            origin.Y += forward.Y * d;
            origin.Z += forward.Z * d + 64;
        }

        var trace = stackalloc GameTrace[1];

        var result = _traceShape(
            *(nint*)gameTraceManagerAddress,
            origin.Handle,
            endOrigin.Handle,
            0,
            0x1C1003,
            4,
           trace);
        

        if (drawResult)
        {
            var color = Color.FromName("Green");
            if (result)
            {
                color = Color.FromName("Red");
            }

            var endPos = new Vector(trace->EndPos.X, trace->EndPos.Y, trace->EndPos.Z);
            DrawBeam(origin, endPos, color);
        }

        if (result)
        {
            var endPos = trace->EndPos;
            return new Vector(endPos.X, endPos.Y, endPos.Z);
        }

        return null;
    }
}

internal static class Address
{
    public static unsafe nint GetAbsoluteAddress(nint addr, nint offset, int size)
    {
        var code = *(int*)(addr + offset);
        return addr + code + size;
    }

    public static nint GetCallAddress(nint a)
    {
        return GetAbsoluteAddress(a, 1, 5);
    }
}

[StructLayout(LayoutKind.Explicit, Size = 0x35)]
public unsafe struct Ray
{
    [FieldOffset(0)] public Vector3 Start;
    [FieldOffset(0xC)] public Vector3 End;
    [FieldOffset(0x18)] public Vector3 Mins;
    [FieldOffset(0x24)] public Vector3 Maxs;
    [FieldOffset(0x34)] public byte UnkType;
}

[StructLayout(LayoutKind.Explicit, Size = 0x44)]
public unsafe struct TraceHitboxData
{
    [FieldOffset(0x38)] public int HitGroup;
    [FieldOffset(0x40)] public int HitboxId;
}

[StructLayout(LayoutKind.Explicit, Size = 0xB8)]
public unsafe struct GameTrace
{
    [FieldOffset(0)] public void* Surface;
    [FieldOffset(0x8)] public void* HitEntity;
    [FieldOffset(0x10)] public TraceHitboxData* HitboxData;
    [FieldOffset(0x50)] public uint Contents;
    [FieldOffset(0x78)] public Vector3 StartPos;
    [FieldOffset(0x84)] public Vector3 EndPos;
    [FieldOffset(0x90)] public Vector3 Normal;
    [FieldOffset(0x9C)] public Vector3 Position;
    [FieldOffset(0xAC)] public float Fraction;
    [FieldOffset(0xB6)] public bool AllSolid;
}

[StructLayout(LayoutKind.Explicit, Size = 0x3a)]
public unsafe struct TraceFilter
{
    [FieldOffset(0)] public void* Vtable;
    [FieldOffset(0x8)] public ulong Mask;
    [FieldOffset(0x20)] public fixed uint SkipHandles[4];
    [FieldOffset(0x30)] public fixed ushort arrCollisions[2];
    [FieldOffset(0x34)] public uint Unk1;
    [FieldOffset(0x38)] public byte Unk2;
    [FieldOffset(0x39)] public byte Unk3;
}

public unsafe struct TraceFilterV2
{
    public ulong Mask;
    public fixed ulong V1[2];
    public fixed uint SkipHandles[4];
    public fixed ushort arrCollisions[2];
    public short V2;
    public byte V3;
    public byte V4;
    public byte V5;
}